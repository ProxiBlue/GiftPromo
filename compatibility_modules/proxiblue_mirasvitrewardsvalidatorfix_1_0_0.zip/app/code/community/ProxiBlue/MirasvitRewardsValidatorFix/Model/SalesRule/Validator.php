<?php

/**
 * Class ProxiBlue_GiftPromo_SalesRule_Model_Validator
 *  determine if a rule can not validate due to coupon blocker
 *
 * This is a copy of the code into a compatibility module
 */
class ProxiBlue_MirasvitRewardsValidatorFix_Model_SalesRule_Validator extends Mirasvit_Rewards_Model_Rewrite_SalesRule_Validator
{
    protected function _canProcessRule($rule, $address)
    {
        $quote = $address->getQuote();
        $appliedRuleIds = $quote->getAppliedRuleIds();
        $appliedRuleIds = explode(',', $appliedRuleIds);

        if (in_array($rule->getId(), $appliedRuleIds)) {
            if ($quote->getQuoteCurrencyCode() == Mage::app()->getStore()->getCurrentCurrencyCode()) {
                $cartGifts = mage::helper('giftpromo')->getRuleBasedCartItems();
                foreach ($cartGifts as $giftItem) {
                    if(is_object($giftItem)) {
                        $ruleObject = $giftItem->getRule();
                        $blockRules = explode(',', $ruleObject->getBlockRules());
                        if (in_array('{ALL}', $blockRules) || in_array($rule->getId(), $blockRules)) {
                            $message = $ruleObject->getBlockRulesMessage();
                            $message = str_replace('{SHOPPING_CART_RULE_NAME}', $rule->getName(), $message);
                            $message = str_replace('{GIFT_RULE_NAME}', $ruleObject->getRuleName(), $message);
                            if (!empty($message)) {
                                mage::helper('giftpromo')->insertFactoryErrorMessage($message);
                            }
                            $rule->setIsValidForAddress($address, false);
                            //$item->setAppliedRuleIds(join(',',$appliedRuleIds));
                            $currentAppliedAddressRules = explode(',', $address->getAppliedRuleIds());
                            $matched = array_search($rule->getId(), $currentAppliedAddressRules);
                            unset($currentAppliedAddressRules[$matched]);
                            $address->setAppliedRuleIds(implode(',', $currentAppliedAddressRules));
                            $quote->setAppliedRuleIds(implode(',', $currentAppliedAddressRules));
                            $quote->setCouponCode('');
                            $quote->collectTotals()->save();
                            return false;
                        }
                    }
                }
            }
        }
        return parent::_canProcessRule($rule, $address);
    }

}
