<?php

/**
 * Fix rewrite clash between amasty stockstatus and proxiblue giftpromo modules
 * 
 * @category   ProxiBlue
 * @package    ProxiBlue_GiftPromo
 * @author     Lucas van Staden (support@proxiblue.com.au)
 **/
class ProxiBlue_AmastyStockStatusGiftPromoRewriteFix_Model_Sales_Quote_Item extends Mage_Sales_Model_Quote_Item {

    /**
     * Check product representation in item
     * 
     * handles checking for the gift products in the cart, to allow multiple qty when the same gift is added
     * handles adding a gift to the cart if the gift item is in cart but not as a gift
     *
     * @param   Mage_Catalog_Model_Product $product
     * @return  bool
     */
    public function representProduct($product) {
        $itemProduct = $this->getProduct();
        $infoBuyRequest = $product->getCustomOption('info_buyRequest');
        if($infoBuyRequest instanceof Mage_Catalog_Model_Product_Configuration_Item_Option){
        $buyRequest = new Varien_Object(unserialize($infoBuyRequest->getValue()));
            if($product->getParentItemId()) {
                return false;
            }
            if ($buyRequest->getAddedByRule()) {
                $itemInfoBuyRequest = $this->getOptionByCode('info_buyRequest');
                $itemBuyRequest = new Varien_Object(unserialize($itemInfoBuyRequest->getValue()));
                if ($buyRequest->getAddedByRule() != $itemBuyRequest->getAddedByRule()){
                        return false;
                }
            }
        }
        if (!$product || $itemProduct->getId() != $product->getId() || $itemProduct->getTypeId() != $product->getTypeId()) {
            return false;
        }
        return parent::representProduct($product);
    }
    
    public function getMessage($string = true)
    {
            if ('checkout' == Mage::app()->getRequest()->getModuleName() && Mage::getStoreConfig('amstockstatus/general/displayincart'))
            {
                if ($this->getProduct()->isConfigurable()) {
                    if (is_array($this->getQtyOptions())) {
                        foreach ($this->getQtyOptions() as $simpleProduct) {
                            $simpleProductId = $simpleProduct->getProductId();
                        }
                    }
                    $product = Mage::getModel('catalog/product')->load($simpleProductId);
                    $stockItem = Mage::getModel('cataloginventory/stock_item')->loadByProduct($product);
                    if (!Mage::helper('amstockstatus')->getCustomStockStatusText($product)) {
                        $product = Mage::getModel('catalog/product')->load($this->getProduct()->getId());
                        $stockItem = Mage::getModel('cataloginventory/stock_item')->loadByProduct($product);
                    }
                } else {
                    $product = Mage::getModel('catalog/product')->load($this->getProduct()->getId());
                    $stockItem = Mage::getModel('cataloginventory/stock_item')->loadByProduct($product);
                }
                
                if ( !(Mage::getStoreConfig('amstockstatus/general/displayforoutonly') && $product->isSaleable()) || ($product->isInStock() && $stockItem->getData('qty') <= Mage::helper('amstockstatus')->getBackorderQnt() ) )
                {
                    if (Mage::helper('amstockstatus')->getCustomStockStatusText($product))
                    {
                        $this->addMessage(Mage::helper('amstockstatus')->getCustomStockStatusText($product));
                    }
                }
            }
        return parent::getMessage($string);
    }
}

